X3D Tooltips are online at
   http://www.web3d.org/x3d/content/X3dTooltips.html

Links to X3D Tooltips English,  Chinese, French, German, Italian, Portuguese and Spanish are available at
   http://www.web3d.org/x3d/content/examples/X3dResources.html#Tooltips

with version control maintained at
   http://x3d.svn.sourceforge.net/viewvc/x3d/www.web3d.org/x3d/tooltips
